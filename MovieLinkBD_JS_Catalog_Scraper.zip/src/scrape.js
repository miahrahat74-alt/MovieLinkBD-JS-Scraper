import { scrapeCatalog } from './scraper.js';
if (!process.env.SITE_BASE_URL) throw new Error('Set SITE_BASE_URL');
console.log(JSON.stringify({results: await scrapeCatalog(process.env.SITE_BASE_URL)}, null, 2));
