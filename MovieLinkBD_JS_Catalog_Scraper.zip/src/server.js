import express from 'express';
import { scrapeCatalog, scrapeItem } from './scraper.js';

const app = express();
const base = process.env.SITE_BASE_URL;
const port = Number(process.env.PORT || 3000);
if (!base) throw new Error('Set SITE_BASE_URL');
const site = new URL(base);

function sameSite(candidate) {
  const u = new URL(candidate, site);
  if (u.origin !== site.origin) throw new Error('URL must belong to SITE_BASE_URL');
  return u.toString();
}

app.get('/api/home', async (_req, res) => {
  try { res.json({ results: await scrapeCatalog(site.toString()) }); }
  catch (e) { res.status(502).json({ error: e.message }); }
});
app.get('/api/search', async (req, res) => {
  const q = String(req.query.q || '').trim().toLowerCase();
  if (!q) return res.status(400).json({ error: 'Missing q' });
  try {
    const results = await scrapeCatalog(site.toString());
    res.json({ results: results.filter(x => x.title.toLowerCase().includes(q)) });
  } catch (e) { res.status(502).json({ error: e.message }); }
});
app.get('/api/item', async (req, res) => {
  try {
    if (!req.query.url) return res.status(400).json({ error: 'Missing url' });
    res.json(await scrapeItem(sameSite(String(req.query.url))));
  } catch (e) { res.status(400).json({ error: e.message }); }
});
app.listen(port, () => console.log(`Catalog API on port ${port}`));
