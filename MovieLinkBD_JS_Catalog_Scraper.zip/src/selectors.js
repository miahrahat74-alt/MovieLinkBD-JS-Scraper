// Adjust these CSS selectors to your own site's HTML.
export const selectors = {
  card: '.movie-card, .post-item, article',
  title: '.title, .entry-title, h2, h3',
  link: 'a', poster: 'img',
  description: '.description, .excerpt',
  year: '.year', genre: '.genre'
};
