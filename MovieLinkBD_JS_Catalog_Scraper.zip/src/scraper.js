import * as cheerio from 'cheerio';
import { selectors } from './selectors.js';

const timeoutMs = Number(process.env.REQUEST_TIMEOUT_MS || 12000);

async function fetchHtml(url) {
  const u = new URL(url);
  if (!['http:', 'https:'].includes(u.protocol)) throw new Error('HTTP(S) only');
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(url, {
      signal: controller.signal,
      headers: { 'User-Agent': 'AuthorizedCatalogBot/1.0' }
    });
    if (!response.ok) throw new Error(`Upstream returned ${response.status}`);
    return await response.text();
  } finally { clearTimeout(timer); }
}

export async function scrapeCatalog(url) {
  const $ = cheerio.load(await fetchHtml(url));
  const results = [];
  $(selectors.card).each((_, el) => {
    const card = $(el);
    const title = card.find(selectors.title).first().text().trim();
    const href = card.find(selectors.link).first().attr('href');
    const img = card.find(selectors.poster).first();
    const poster = img.attr('data-src') || img.attr('src');
    if (!title || !href) return;
    results.push({
      title, url: new URL(href, url).toString(),
      poster: poster ? new URL(poster, url).toString() : null,
      description: card.find(selectors.description).first().text().trim() || null,
      year: card.find(selectors.year).first().text().trim() || null,
      genre: card.find(selectors.genre).first().text().trim() || null
    });
  });
  return results;
}

export async function scrapeItem(url) {
  const $ = cheerio.load(await fetchHtml(url));
  const title = $('meta[property="og:title"]').attr('content')
    || $(selectors.title).first().text().trim() || $('title').text().trim();
  const description = $('meta[name="description"]').attr('content')
    || $('meta[property="og:description"]').attr('content')
    || $(selectors.description).first().text().trim();
  const poster = $('meta[property="og:image"]').attr('content')
    || $(selectors.poster).first().attr('src');
  return { title, url, description: description || null,
    poster: poster ? new URL(poster, url).toString() : null };
}
