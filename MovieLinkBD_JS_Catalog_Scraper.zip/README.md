# MovieLinkBD JS Catalog Scraper

Node.js + Cheerio metadata scraper starter for a site you own or are authorized to access.

## Provides
- `GET /api/home`
- `GET /api/search?q=term`
- `GET /api/item?url=https://your-site.example/path`

## Setup
1. Install Node.js 20+.
2. Run `npm install`.
3. Copy `.env.example` to `.env` and set `SITE_BASE_URL`.
4. Edit `src/selectors.js` to match your site's HTML.
5. Run `npm start` and test `/api/home`.

This is a configurable starter, not a finished site adapter. It extracts catalog metadata only; it does not extract video streams, bypass access controls, or defeat CAPTCHAs. Use only content and pages you are authorized to process.

Cloudstream extensions are normally Kotlin. A Kotlin `MainAPI` provider can consume this JSON API and map metadata to Cloudstream models. Host the API over HTTPS before using it in an extension.

## Publish to GitHub
Create a repository, then run:
```bash
git init
git add .
git commit -m "Initial catalog scraper"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/movielinkbd-js-catalog-scraper.git
git push -u origin main
```
